package com.itheima.test01;

/**
 需求说明
    请说出四种运行时异常
 */
public class Test03 {
    /*索引越界异常:IndexOutOfBoundsException
    数组索引越界异常:ArrayIndexOutOfBoundsException
    字符串索引越界异常:StringIndexOutOfBoundsException
    空指针异常: NullPointerException
    算术异常:ArithmeticException*/
}
