package com.itheima.test01;

/**
 需求说明
    请说出虚拟机处理异常的方式
 */
public class Test02 {
    /*
    1.把异常对象的类名,异常内容,异常出现的位置信息打印到控制台上
    2.	终止程序执行*/
}
